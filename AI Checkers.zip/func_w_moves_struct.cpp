#include <iostream>
#include <windows.h>
#include <fstream>
#include <string>
#include <vector>
#include <queue> 
#include <algorithm>
#include <cstdlib>
#include <chrono>
using namespace std;

int blkb_whtt = 15;
int redb_yelt = 206;
int yelb_blut = 233;
int cynb_blut = 185;
int whtb_blkt = 240;
int time_limit;




HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

vector<int> i_captured = { 0 };
vector<int> j_captured = { 0 };

const int board_width = 8;
const int board_height = 8;
const int nopiece = 0;
const int norm1 = 3;
const int king1 = 5;
const int norm2 = -3;
const int king2 = -5;
int move_number;
vector<int> zero_vector = { 0 };
vector<int> i_moves;
vector<int> j_moves;
vector<vector<int>> moves;
const int inf = INT_MAX;

struct Move
{
	int score;
	int value;
	int player;
	int checkers_board[64];
	vector<int> i;
	vector<int> j;
	vector<int> captured_i;
	vector<int> captured_j;
	vector<Move*> child;

};

Move* newMove(vector<int> i, vector<int> j, vector<int> captured_i, vector<int> captured_j, int player)
{
	Move* temp = new Move;
	temp->i = i;
	temp->j = j;
	temp->captured_i = captured_i;
	temp->captured_j = captured_j;
	temp->player = player;
	return temp;
}


vector<Move*> movestree;
Move* movesroot = newMove(zero_vector, zero_vector, zero_vector, zero_vector, 0);
Move* treemovesroot = newMove(zero_vector, zero_vector, zero_vector, zero_vector, 0);

void store_board_in_tree_moves_root(int checkers_board[64])
{
	memcpy(treemovesroot->checkers_board, checkers_board, sizeof(treemovesroot->checkers_board));
}

void store_player_in_tree_moves_root(int player)
{
	treemovesroot->player=player;
}

//int checkers_board[board_width][board_height];

struct Piece
{
	int value;
	int current_i;
	int current_j;
	int captured_i;
	int captured_j;
	int next_i;
	int next_j;
	vector<Piece*>child;
};

Piece* newPiece(int current_i, int current_j, int value)
{
	Piece* temp = new Piece;
	temp->value = value;
	temp->current_i = current_i;
	temp->current_j = current_j;
	return temp;
}

Piece* masterroot = newPiece(0, 0, 0);
queue<Piece*> q;  // Create a queue 

void clear_piece_q(std::queue<Piece*>& q)
{
	std::queue<Piece*> empty;
	std::swap(q, empty);
}

void store_time_limit(int timeLimit)
{
	time_limit = timeLimit*1000;
}

int avg(int a, int b)
{
	return (a + b) / 2;
}

int pos(int i, int j)
{
	return i * board_width + j;
}

void print_board(int checkers_board[64])
{
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			cout << checkers_board[pos(i, j)] << " ";
		}

		// Newline for new row
		cout << endl;
	}
}

bool load_file()
{
	char load;
	cout << endl << "   Would you like to load game from a file? (y or n) : ";
	cin >> load;
	cout << endl;

	while ( ((load != 'Y') && (load != 'y') && (load != 'N') && (load != 'n')) || cin.fail())
	{
		cin.clear();
		cin.ignore(256, '\n');
		cout << "   Please enter a valid character for your move choice (y or n): ";
		cin >> load;
	}
	if (load == 'Y' || load == 'y')
	{
		return 1;
	}
	else if (load == 'N' || load == 'n')
	{
		return 0;
	}
}

bool determine_player1()
{
	char player1gender; // gender of 0 is human player, gender of 1 is computer player
	cout << "   Will Player 1 be a computer? (Y/N) : ";
	cin >> player1gender;
	cout << endl;

	while (((player1gender != 'Y') && (player1gender != 'y') && (player1gender != 'N') && (player1gender != 'n')) || cin.fail())
	{
		cin.clear();
		cin.ignore(256, '\n');
		cout << "   Will Player 1 be a computer? (Please enter Y/y for yes or N/n for no) :  ";
		cin >> player1gender;
	}
	
	
	if (player1gender == 'Y' || player1gender == 'y')
	{
		return 1;
	}
	else if (player1gender == 'N' || player1gender == 'n')
	{
		return 0;
	}
	
}

bool determine_player2()
{
	char player2gender; // gender of 0 is human player, gender of 1 is computer player
	cout << "   Will Player 2 be a computer? (Y/N) : ";
	cin >> player2gender;
	cout << endl;

	while (((player2gender != 'Y') && (player2gender != 'y') && (player2gender != 'N') && (player2gender != 'n')) || cin.fail())
	{
		cin.clear();
		cin.ignore(256, '\n');
		cout << "   Will Player 2 be a computer? (Please enter Y/y for yes or N/n for no) :  ";
		cin >> player2gender;
	}


	if (player2gender == 'Y' || player2gender == 'y')
	{
		return 1;
	}
	else if (player2gender == 'N' || player2gender == 'n')
	{
		return 0;
	}

}

size_t move_first()
{
	unsigned player = 0; // gender of 0 is human player, gender of 1 is computer player
	cout << "   Which Player will move first? ( 1 or 2 ): ";
	cin >> player;
	cout << endl;

	while ( ( (player != 1) && (player != 2) ) || cin.fail())
	{
		cin.clear();
		cin.ignore(256, '\n');
		cout << "   Please enter a valid number for which player will move first? ( Either integer 1 or 2 ):  ";
		cin >> player;
	}


	if (player == 1)
	{
		return 1;
	}
	else if (player == 2)
	{
		return 2;
	}

}

int load_file_contents_player(string path)
{
	
	static int arr[34];

	fstream inFileStr(path, ios::in);
	if (inFileStr.fail()) {
		cerr << "Unable to open " << path << endl;
		exit(-1);
	}

	int value;
	int i = 0;
	while (inFileStr >> value)
	{
		arr[i] = value;
		//cout << "  " << arr[i] << endl;
		i++;
	}

	int player = arr[32];
	return player;
	

}

int* load_file_contents(string path)
{
	static int checkers_board[board_width * board_height] = { 0 };
	static int arr[34];

	fstream inFileStr(path, ios::in);
	if (inFileStr.fail()) {
		cerr << "Unable to open " << path << endl;
		exit(-1);
	}

	int value;
	int i = 0;
	while (inFileStr >> value)
	{
		arr[i] = value;
		//cout << "  " << arr[i] << endl;
		i++;
	}

	int player = arr[32];
	treemovesroot->player = player;
	cout << endl << "   It's Player " << player << "'s turn" << endl;
	time_limit = arr[33];
	cout << "   The Computer's time limit is " << time_limit << " seconds" << endl;
	time_limit = arr[33] * 1000;
	cout << endl;

	for (int i = 0; i < sizeof(arr) / 4; i++)
	{
		//cout << "Array value at position " << i << " = " << arr[i] << endl;

		if (arr[i] == 1)
			arr[i] = norm1;
		else if (arr[i] == 2)
			arr[i] = norm2;
		else if (arr[i] == 3)
			arr[i] = king1;
		else if (arr[i] == 4)
			arr[i] = king2;


	}

	int counter = 0;
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			//cout << "Counter = " << counter << endl;


			if ((i % 2) == 0 && (j % 2) == 1)
			{
				//cout << "Loading " << arr[counter] << " into position " << i << "," << j << endl;
				checkers_board[pos(i, j)] = arr[counter];
				counter++;
			}
			else if ((i % 2) == 1 && (j % 2) == 0)
			{
				//cout << "Loading " << arr[counter] << " into position " << i << "," << j << endl;
				checkers_board[pos(i, j)] = arr[counter];
				counter++;
			}


		}

	}
	//print_board(checkers_board);
	return checkers_board;

}


string get_file_path()
{
	
	cout << "   The file should be a .txt file with the following format: " << endl << endl;
	cout << "     0   0   0   0" << endl;
	cout << "   3   0   0   0 " << endl;
	cout << "     4   2   3   0" << endl;
	cout << "   0   0   0   0 " << endl;
	cout << "     4   2   4   0" << endl;
	cout << "   0   0   0   0 " << endl;
	cout << "     1   4   2   0" << endl;
	cout << "   0   0   3   0 " << endl;
	cout << "   1" << endl;
	cout << "   10" << endl << endl;
	cout << "   Where The first 8 rows of a file represent the state of the board (the spacing is not important)." << endl;
	cout << "   0 = an empty square" << endl;
	cout << "   1 = a regular piece for player 1 " << endl;
	cout << "   2 = a regular piece for player 2" << endl;
	cout << "   3 = a king for player 1" << endl;
	cout << "   4 = a king for player 2" << endl << endl;
	cout << "   The numbers in the final two rows represent : " << endl;
	cout << "   1. Whose turn it is(player 1 or 2) " << endl;
	cout << "   2. The time limit(for any turn played by the computer)." << endl << endl;
	cout << "   Please enter a file path that you would like to load your game from (Separate folders with either /, \\, or \\\\ ) : ";
	
	char path[1000];
	cin.ignore();
	cin.getline(path, sizeof(path));


	//cin >> path;  // = "C:/Users/enead/Desktop/Enea Dushaj/School/Artificial Intelligence/Checkers Game/Sample Boards/Sample Checkers board #10.txt";

	while (cin.fail())
	{
		cin.clear();
		cin.ignore(256, '\n');
		cout << "   Please retry entering a valid file path : ";
		cin >> path;
	}
	
	return path;
}

void create_time_limit()
{
	int time_limit;
	cout << "   Please enter a time limit for the computer (integer between 3 to 60 seconds) : ";
	cin >> time_limit;
	cout << endl;

	while (((time_limit < 3) || (time_limit > 60)) || cin.fail())
	{
		cin.clear();
		cin.ignore(256, '\n');
		cout << "   Please retry entering a valid time limit for the computer (integer between 3 to 60 seconds) : ";
		cin >> time_limit;
	}
	store_time_limit(time_limit);
}


int* copy_array(int arr[])
{
	static int copy[64];
	for (int i = 0; i < 64; i++)
	{
		copy[i] = arr[i];
	}
	return copy;
}

int* create_starting_board()
{
	static int checkers_board[board_width * board_height];
	for (int m = 0; m < 8; m++)
	{
		for (int n = 0; n < 8; n++)
		{
			if (m == 3 || m == 4)
			{
				checkers_board[m * board_width + n] = nopiece;
				//cout << m << "," << n << " = " << checkers_board[m][n] << endl;
			}

			//Print player 1's pieces
			else if (m % 2 == 0 && m < 3)
			{
				if (n % 2 == 1)
				{
					checkers_board[m * board_width + n] = norm2;
					//cout << m << "," << n << " = " << checkers_board[m][n] << endl;
				}
				else if (n % 2 == 0)
				{
					checkers_board[m * board_width + n] = nopiece;
					//cout << m << "," << n << " = " << checkers_board[m][n] << endl;
				}
			}

			else if (m % 2 == 1 && m < 3)
			{
				if (n % 2 == 0)
				{
					checkers_board[m * board_width + n] = norm2;
					//cout << m << "," << n << " = " << checkers_board[m][n] << endl;
				}
				else if (n % 2 == 1)
				{
					checkers_board[m * board_width + n] = nopiece;
					//cout << m << "," << n << " = " << checkers_board[m][n] << endl;
				}
			}

			// Print player 2's pieces

			else if (m % 2 == 0 && m > 4)
			{
				if (n % 2 == 1)
				{
					checkers_board[m * board_width + n] = norm1;
					//cout << m << "," << n << " = " << checkers_board[m][n] << endl; // Print the value associated with each square on the matrix
				}
				else if (n % 2 == 0)
				{
					checkers_board[m * board_width + n] = nopiece;
					//cout << m << "," << n << " = " << checkers_board[m][n] << endl; // Print the value associated with each square on the matrix
				}
			}

			else if (m % 2 == 1 && m > 4)
			{
				if (n % 2 == 0)
				{
					checkers_board[m * board_width + n] = norm1;
					//cout << m << "," << n << " = " << checkers_board[m][n] << endl; // Print the value associated with each square on the matrix
				}
				else if (n % 2 == 1)
				{
					checkers_board[m * board_width + n] = nopiece;
					//cout << m << "," << n << " = " << checkers_board[m][n] << endl; // Print the value associated with each square on the matrix
				}
			}

		}
	}
	//for (int i = 0; i < 8; i++)
	//{
	//	for (int j = 0; j < 8; j++)
	//	{
	//		cout << checkers_board[i][j] << " ";
	//	}

	//	// Newline for new row 
	//	cout << endl;
	//}
	return checkers_board;
}

void bw()
{
	SetConsoleTextAttribute(hConsole, blkb_whtt);
}
void wb()
{
	SetConsoleTextAttribute(hConsole, whtb_blkt);
}
void ry()
{
	SetConsoleTextAttribute(hConsole, redb_yelt);
}
void yb()
{
	SetConsoleTextAttribute(hConsole, yelb_blut);
}
void cb()
{
	SetConsoleTextAttribute(hConsole, cynb_blut);
}

void p1norm()
{
	cb();
	cout << "..";
	bw();
}
void p1king()
{
	cb();
	cout << "##";
	bw();
}
void p2norm()
{
	yb();
	cout << "..";
	bw();
}
void p2king()
{
	yb();
	cout << "##";
	bw();
}

void p1stment()
{
	cout << endl;
	bw();
	cout << "         Player 1 is ";
	p1norm();
	cout << " (normal piece) and ";
	p1king();
	cout << " (king)" << endl;
}
void p2stment()
{
	bw();
	cout << "         Player 2 is ";
	p2norm();
	cout << " (normal piece) and ";
	p2king();
	cout << " (king)" << endl;
}

void color_swatch()
{
	for (int k = 0; k < 255; k++)
	{
		// pick the colorattribute k you want
		SetConsoleTextAttribute(hConsole, k);
		cout << k << " I want to be nice today!" << endl;
	}
}
// you can loop k higher to see more color choices

void print_line()
{
	cout << endl << "   ---------------------------------------------------------" << endl;
}
void blackblock()
{
	bw();
	cout << "      |";
}
void p1normblock()
{
	bw();
	cout << "  ";
	p1norm();
	cout << "  |";
}
void p1kingblock()
{
	bw();
	cout << "  ";
	p1king();
	cout << "  |";
}
void p2normblock()
{
	bw();
	cout << "  ";
	p2norm();
	cout << "  |";
}
void p2kingblock()
{
	bw();
	cout << "  ";
	p2king();
	cout << "  |";
}
void redblock()
{
	ry();
	cout << "      ";
	bw();
	cout << "|";

}
void redrow(int row)
{
	for (int i = 0; i < 3; i++)
	{
		if (i == 1)
		{
			cout << " " << row << " |";
		}
		else
		{
			cout << "   |";
		}
		for (int k = 0; k < 4; k++)
		{
			if (i == 1)
			{
				redblock();
				p1normblock();
			}
			else
			{
				redblock();
				blackblock();
			}

		}
		cout << endl;
	}
}
void blackrow(int row)
{

	for (int i = 0; i < 3; i++)
	{
		if (i == 1)
		{
			cout << " " << row << " |";
		}
		else
		{
			cout << "   |";
		}
		for (int k = 0; k < 4; k++)
		{
			if (i == 1)
			{
				p1normblock();
				redblock();
			}
			else
			{
				blackblock();
				redblock();
			}
		}
		cout << endl;
	}
}
void print_columns()
{
	cout << "   ";
	for (int i = 0; i < 8; i++)
	{
		if (i == 7)
		{
			cout << "   " << i << "   ";
		}
		else
		{
			cout << "   " << i << "   ";
		}
	}
}

void make_kings(int checkers_board[64])
{
	for (size_t j = 0; j < 4; j++)
	{
		if (checkers_board[pos(0, 2 * j + 1)] == norm1)
		{
			checkers_board[pos(0, 2 * j + 1)] = king1;
			//cout << "New player 1 king located at 0," << 2 * j + 1 << endl;
		}
		if (checkers_board[pos(7, 2 * j)] == norm2)
		{
			checkers_board[pos(7, 2 * j)] = king2;
			//cout << "New player 2 king located at 7," << 2 * j  << endl;
		}
	}
}

void print_board_with_pieces(int checkers_board[64])
{
	make_kings(checkers_board);

	//static const int nopiece = 0;
	//static const int norm1 = 1;
	//static const int king1 = 2;
	//static const int norm2 = -1;
	//static const int king2 = -2;

	p1stment();
	p2stment();

	cout << endl;
	print_columns();
	print_line();

	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			if (j > 0)
			{
				cout << endl;
			}
			for (int k = 0; k < 8; k++)
			{
				if (j == 1 && k == 0)
				{
					cout << " " << i << " |";
				}
				else if ((j == 0 || j == 2) && k == 0)
				{
					cout << "   |";
				}
				//				cout << "board value at " << i << "," << k << "," << j << " = " << checkers_board[i][k];
				if (j == 0 || j == 2)
				{
					if (i % 2 == 0)
					{
						if (k % 2 == 0)
						{
							redblock();
						}
						else
						{
							blackblock();
						}
					}
					else if (i % 2 == 1)
					{
						if (k % 2 == 0)
						{
							blackblock();
						}
						else
						{
							redblock();
						}
					}
				}

				else if (j == 1)
				{
					if (i % 2 == 0)
					{
						if (k % 2 == 1)
						{
							// Player 1's Pieces
							if (checkers_board[i * board_width + k] == norm1)
							{
								p1normblock();
							}
							else if (checkers_board[i * board_width + k] == king1)
							{
								p1kingblock();
							}

							// Player 2's Pieces
							else if (checkers_board[i * board_width + k] == norm2)
							{
								p2normblock();
							}
							else if (checkers_board[i * board_width + k] == king2)
							{
								p2kingblock();
							}
							else
							{
								blackblock();
							}
						}
						else
						{
							redblock();
						}
					}

					else
					{
						if (k % 2 == 1)
						{
							redblock();
						}
						else
						{
							// Player 1's Pieces
							if (checkers_board[i * board_width + k] == norm1)
							{
								p1normblock();
							}
							else if (checkers_board[i * board_width + k] == king1)
							{
								p1kingblock();
							}

							// Player 2's Pieces
							else if (checkers_board[i * board_width + k] == norm2)
							{
								p2normblock();
							}
							else if (checkers_board[i * board_width + k] == king2)
							{
								p2kingblock();
							}
							// Empty blocks
							else
							{
								blackblock();
							}
						}
					}
				}
			}
		}
		print_line();
	}
}

bool within_bounds(int i, int j)
{
	if (i > -1 && i < 8 && j > -1 && j < 8)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool is_capturable_enemy(int checkers_board[64], int& i, int& j, int p, int dir, int& enemynorm, int& enemyking)
{

	//cout << endl << "Checking to see if piece is capturable : " << i - p << "," << j + dir << endl << endl;
	//cout << "Value of board at position " << (i - p) << "," << (j +  dir) << " = " << checkers_board[pos((i - p), (j + dir))] << " which should be -3 or -5" << endl;
	//cout << "Value of board at position " << (i - 2 * p) << "," << (j + 2 * dir) << " = " << checkers_board[pos((i - 2 * p), (j + 2 * dir))] << " which should be zero" << endl;
	if (((checkers_board[pos((i - p), (j + dir))] == enemynorm) || (checkers_board[pos((i - p), (j + dir))] == enemyking)) && ((checkers_board[pos((i - 2 * p), (j + 2 * dir))] == nopiece) && within_bounds((i - 2 * p), (j + 2 * dir))))
	{
		//if ( (checkers_board[pos((i - 2 * p), (j + 2 * dir))] == nopiece) && within_bounds( (i - 2*p) , (j + 2*dir )) )
		//{
			//cout << "Value of board at position " << (i - 2 * p) << "," << (j + 2 * dir) << " = " << checkers_board[pos((i - 2 * p), (j + 2 * dir))] << endl;
		//cout << "Capturable enemy from position " << i << "," << j << endl;
		//cout << endl << "Enemy is capturable at  : " << i - p << "," << j + dir << endl << endl;
		return 1;
		//}
	}
	else
	{
		//cout << endl << "Enemy is NOT capturable at  : " << i - p << "," << j + dir << endl << endl;
		return 0;
	}
	//}

}

void check_open(int checkers_board[64], int i, int j, int p, int dir, int current_pose_val, Piece* currentnode)
{
	if (checkers_board[(i - p) * board_width + (j + dir)] == nopiece)
	{
		if (within_bounds(i - p, j + dir))
		{
			i = i - p;
			j = j + dir;

			(currentnode->child).push_back(newPiece(i, j, current_pose_val));
			currentnode = (currentnode->child).back();
		}
	}


	//cout << "The current node is at position " << currentnode->current_i << "," << currentnode->current_j << " I captured the piece at position " << currentnode->captured_i << "," << currentnode->captured_j << endl;


			//cout << "Legal Move Detected: " << i << "," << j << " to " << i - p << "," << j + dir << endl;
}

bool is_force_jump(int checkers_board[64], int p, int left, int right, int enemynorm, int enemyking, int friendlynorm, int friendlyking)
{
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			//cout << "At position : " << i << "," << j << endl; // " is value : " << checkers_board[pos(i, j)] << " and is_capturable to the left and right = " << is_capturable_enemy(checkers_board, i, j, p, left, enemynorm, enemyking) << "," << is_capturable_enemy(checkers_board, i, j, p, right, enemynorm, enemyking) << endl;
			//if (((checkers_board[pos(i, j)] == friendlynorm) || (checkers_board[pos(i, j)] == friendlyking)))
				//cout << "At position : " << i << "," << j << " is a friendly : " << checkers_board[pos(i, j)] << endl;
			if ((checkers_board[pos(i, j)] == friendlynorm) && ((is_capturable_enemy(checkers_board, i, j, p, left, enemynorm, enemyking)) || is_capturable_enemy(checkers_board, i, j, p, right, enemynorm, enemyking)))
			{
				//if ((is_capturable_enemy(checkers_board, i, j, p, left, enemynorm, enemyking)) || is_capturable_enemy(checkers_board, i, j, p, right, enemynorm, enemyking));
				//{
					//cout << "Force Jump Found" << " at position : " << i << "," << j << endl;
				return true;   //// Its always setting force jump to be true. If you comment out force jump, normal moves work
			//}

			}

			else if ((checkers_board[pos(i, j)] == friendlyking) && ((is_capturable_enemy(checkers_board, i, j, p, left, enemynorm, enemyking)) || is_capturable_enemy(checkers_board, i, j, p, right, enemynorm, enemyking) || (is_capturable_enemy(checkers_board, i, j, -p, left, enemynorm, enemyking)) || is_capturable_enemy(checkers_board, i, j, -p, right, enemynorm, enemyking)))
			{
				//if ((is_capturable_enemy(checkers_board, i, j, p, left, enemynorm, enemyking)) || is_capturable_enemy(checkers_board, i, j, p, right, enemynorm, enemyking));
				//{
					//cout << "Force Jump Found" << " at position : " << i << "," << j << endl;
				return true;
				//}

			}

		}

	}
	return false;
}


/* Prototypes for functions needed in printPaths() */
void printPathsRecur(Piece* node, int path_i[], int path_j[], int pathLen);
void printArray(int path_i[], int path_j[], int len);


/*Given a binary tree, print out all of its root-to-leaf
paths, one per line. Uses a recursive helper to do the work.*/
void printPaths(Piece* node)
{
	int path_i[1000];
	int path_j[1000];
	printPathsRecur(node, path_i, path_j, 0);
}
void getIndex(vector<int> v, int K)
{
	auto it = find(v.begin(), v.end(), K);

	// If element was found 
	if (it != v.end()) {
		// calculating the index 
		// of K 
		int index = distance(v.begin(),
			it);
		cout << index << endl;
	}
	else {
		// If the element is not 
		// present in the vector 
		cout << "-1" << endl;
	}
}
/* Recursive helper function -- given a node,
and an array containing the path from the root
node up to but not including this node,
print out all the root-leaf paths.*/
void printPathsRecur(Piece* node, int path_i[], int path_j[], int pathLen)
{
	if (node == NULL)
		return;

	/* append this node to the path array */

	path_i[pathLen] = node->current_i;
	path_j[pathLen] = node->current_j;
	//cout << "Adding " << path_i[pathLen] << "," << path_j[pathLen] << " to the current i,j positions" << endl;

	pathLen++;
	//cout << pathLen << endl;

	bool isleaf = 1;
	for (size_t i = 0; i < (node->child).size(); i++)
	{
		if ((node->child[i]->value) != 0)
			isleaf = 0;

	}

	if (isleaf == 1)
	{
		printArray(path_i, path_j, pathLen);
	}
	else
	{
		for (size_t i = 0; i < (node->child).size(); i++)
		{
			printPathsRecur(node->child[i], path_i, path_j, pathLen);
		}
	}
}
void printArray(int path_i[], int path_j[], int len)
{
	vector<int> moves_i;
	vector<int> moves_j;
	int i;
	for (i = 0; i < len; i++)
	{

		if (i == 0)
		{
			cout << "   Move " << move_number << ": ";
			move_number++;
		}
		else if (i == 1)
			cout << "(" << path_i[i] << "," << path_j[i] << ") ";
		else
			cout << "=> " << "(" << path_i[i] << "," << path_j[i] << ") ";

		moves_i.push_back(path_i[i]);
		moves_j.push_back(path_j[i]);

	}
	cout << endl;



	moves.push_back(moves_i);
	moves.push_back(moves_j);


	//cout << 2 * move_number-2 << endl;
	//cout << 2 * move_number - 1 << endl;

}


int* remove_pieces(int checkers_board[64], Move* move)
{
	static int temp_board[64] = { 0 };
	memcpy(temp_board, checkers_board, sizeof(temp_board));


	int size = (move->i).size();
	int sum = 0;


	int initial_i = ((move->i)[1]);
	int initial_j = ((move->j)[1]);
	int final_i = ((move->i).back());
	int final_j = ((move->j).back());

	int location_i;
	int location_j;
	int future_i;
	int future_j;

	int temp = temp_board[pos(initial_i, initial_j)];
	//cout << "board at position " << initial_i << "," << initial_j << " = " << temp << endl;

	//cout << "The move choice has " << (moves[move_choice]).size() << " Points " << endl ;
	for (int i = 1; i < size - 1; i++)
	{
		location_i = ((move->i)[i]);
		location_j = ((move->j)[i]);

		future_i = ((move->i)[i + 1]);
		future_j = ((move->j)[i + 1]);
		
		
		//cout << "Moving from position " << location_i << "," << location_j << " to " << future_i << "," << future_j << endl;
		
		
		if ((abs(future_i - location_i) > 1) && (abs(future_j - location_j) > 1))
		{
			sum += temp_board[pos(avg(location_i, future_i), avg(location_j, future_j))];
			//cout << "Removed pieces at locations " << avg(location_i, future_i) << "," << avg(location_j, future_j) << " worth " << temp_board[pos(avg(location_i, future_i), avg(location_j, future_j))] << " points" << endl;
			temp_board[pos(avg(location_i, future_i), avg(location_j, future_j))] = nopiece;
		}
	}




	temp_board[pos(initial_i, initial_j)] = nopiece;
	//cout << "intial position: " << initial_i<< "," << initial_j << " has value: " << checkers_board[pos(initial_i, initial_j)]<<  endl;
	//cout << "final position: " << final_i << "," << final_j << " has value: " << checkers_board[pos(final_i, final_j)] << endl;
	temp_board[pos(final_i, final_j)] = temp;
	//cout << "board at position " << final_i << "," << final_j << " = " << temp_board[pos(final_i, final_j)] << endl;


	//cout << "Opposing gy player will lose " << abs(sum) << " points" << endl;
	move->value = sum;

	
	return temp_board;
}

int count_pieces(int checkers_board[64], int player)
{
	int player1count = 0;
	int player2count = 0;
	
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			if (checkers_board[pos(i, j)] > 0)
			{
				player1count += checkers_board[pos(i, j)];
				//cout << count << endl;
			}
			else if (checkers_board[pos(i, j)] < 0)
			{
				player2count += checkers_board[pos(i, j)];
			}
		}
	}
	if (player == 1) 
	{
		return player1count;
	}
	else if (player == 2)
	{
		return player2count;
	}
}



void getPaths(int checkers_board[64], Piece* node, Move* movesroot);
void getPathsRecur(int checkers_board[64], Piece* node, int path_i[], int path_j[], int pathLen, Move* currentnode);
void getArray(int checkers_board[64], int path_i[], int path_j[], int len, Move* currentnode);


void getPaths(int checkers_board[64], Piece* node, Move* movesroot)
{
	int path_i[1000];
	int path_j[1000];
	getPathsRecur(checkers_board, node, path_i, path_j, 0, movesroot);
}
void getPathsRecur(int checkers_board[64], Piece* node, int path_i[], int path_j[], int pathLen, Move* currentnode)
{
	if (node == NULL)
		return;
	else if (currentnode == 0)
		return;

	/* append this node to the path array */

	path_i[pathLen] = node->current_i;
	path_j[pathLen] = node->current_j;
	//cout << "Adding " << path_i[pathLen] << "," << path_j[pathLen] << " to the current i,j positions" << endl;

	pathLen++;
	//cout << pathLen << endl;

	bool isleaf = 1;
	for (size_t i = 0; i < (node->child).size(); i++)
	{
		if ((node->child[i]->value) != 0)
			isleaf = 0;

	}

	if (isleaf == 1)
	{
		getArray(checkers_board, path_i, path_j, pathLen, currentnode);
	}
	else
	{
		for (size_t i = 0; i < (node->child).size(); i++)
		{
			getPathsRecur(checkers_board, node->child[i], path_i, path_j, pathLen, currentnode);
		}
	}
}
void getArray(int checkers_board[64], int path_i[], int path_j[], int len, Move* currentnode)
{
	vector<int> moves_i;
	vector<int> moves_j;
	int i;
	for (i = 0; i < len; i++)
	{

		moves_i.push_back(path_i[i]);
		moves_j.push_back(path_j[i]);

	}

	/*if (force_jump == 1)
	{
		currentnode->child.push_back(newMove(moves_i, moves_j, zero_vector, zero_vector, currentnode->player % 2 + 1));
	}*/

	currentnode->child.push_back(newMove( moves_i,moves_j,zero_vector, zero_vector, currentnode->player%2+1));
	int* newboard = remove_pieces(checkers_board, (currentnode->child).back());
	make_kings(newboard);
	memcpy(currentnode->child.back()->checkers_board, newboard, sizeof(currentnode->child.back()->checkers_board));

	


	//cout << "This move gets " << (currentnode->child).back()->value << " points " << endl;

	//cout << "Current node's child size is " << currentnode->child.size() << endl;


	//print_board(currentnode->child.back()->checkers_board);
	//cout << endl;

	//print_board(currentnode->child.back()->checkers_board);
	//cout <<endl << currentnode->child.size() << endl;
	
	//print_board_with_pieces(currentnode->child.back()->checkers_board);
	
	//vector<int> iii = currentnode->child.back()->i;
	//vector<int> jjj = currentnode->child.back()->j;

	//for (i = 0; i < len; i++)
	//{

	//	if (i == 0)
	//	{
	//		cout << "Move " << move_number << ": ";
	//		move_number++;
	//	}
	//	else if (i == 1)
	//		cout << "(" << iii[i] << "," << jjj[i] << ") ";
	//	else
	//		cout << "=> " << "(" << iii[i] << "," << jjj[i] << ") ";

	//}
	//cout << endl;

}








void check_captures(int checkers_board[64], int i, int j, int p, int dir, int enemynorm, int enemyking, int current_pose_val, Piece* currentnode)
{

	static bool breadcrumb = 0;
	if ((is_capturable_enemy(checkers_board, i, j, p, dir, enemynorm, enemyking)) && within_bounds((i - 2 * p), (j + 2 * dir)))
	{

		for (size_t ii = 0; ii < i_captured.size(); ii++)
		{
			if (((i - p) == i_captured[ii]) && ((j + dir) == j_captured[ii]))
			{
				breadcrumb = 1;
				break;
			}
		}

		if (breadcrumb == 0)
		{
			//cout << "Legal Move Detected: " << i << "," << j << " to " << i - 2 * p << "," << j + 2 * dir << endl;

			i_captured.push_back(i - p);
			j_captured.push_back(j + dir);

			currentnode->captured_i = i - p;
			currentnode->captured_j = j + dir;

			i = i - 2 * p;
			j = j + 2 * dir;

			(currentnode->child).push_back(newPiece(i, j, current_pose_val));



			//cout << "The current node is at position " << currentnode->current_i << "," << currentnode->current_j << " I captured the piece at position " << currentnode->captured_i << "," << currentnode->captured_j << endl;

			currentnode = (currentnode->child).back();

			//cout << "My new node is at position " << currentnode->current_i << "," << currentnode->current_j << endl; // NEW NODES ARE HAPPENING AT WEIRD POSITIONS


			if (current_pose_val == norm1 || current_pose_val == norm2)
			{
				check_captures(checkers_board, i, j, p, dir, enemynorm, enemyking, current_pose_val, currentnode);
				check_captures(checkers_board, i, j, p, -dir, enemynorm, enemyking, current_pose_val, currentnode);

			}
			else if (current_pose_val == king1 || current_pose_val == king2)
			{
				check_captures(checkers_board, i, j, p, dir, enemynorm, enemyking, current_pose_val, currentnode);

				check_captures(checkers_board, i, j, p, -dir, enemynorm, enemyking, current_pose_val, currentnode);

				check_captures(checkers_board, i, j, -p, dir, enemynorm, enemyking, current_pose_val, currentnode);

				check_captures(checkers_board, i, j, -p, -dir, enemynorm, enemyking, current_pose_val, currentnode);

				//cout << "This root has this many children : " << (currentnode->child).size() << endl;
				//cout << "The root is at position " << currentnode->current_i << "," << currentnode->current_j << " and has children located at: " << endl;
				//for (int size_t = 0; i < (currentnode->child).size(); i++)
					//cout << currentnode->child[i]->current_i << "," << currentnode->child[i]->current_j << endl;


			}



		}

		breadcrumb = 0;

	}



}

// Prints the n-ary tree level wise 
void LevelOrderTraversal(Move* root)
{
	
	if (root == NULL)
		return;

	std::vector<char> path;
	// Standard level order traversal code 
	// using queue 
	queue<Move*> q;  // Create a queue 
	q.push(root); // Enqueue root  
	while (!q.empty())
	{
		int n = q.size();

		// If this node has children 
		while (n > 0)
		{
			// Dequeue an item from queue and print it 
			Move* p = q.front();
			q.pop();
			cout << (p->i).back() << "," << (p->j).back() << " ";

			// Enqueue all children of the dequeued item 
			for (size_t i = 0; i < p->child.size(); i++)
				q.push(p->child[i]);
			n--;
		}

		cout << endl; // Print new line between two levels 
	}
}





void legalmoves(int checkers_board[64], int player)
{

	static const int left = -1;
	static const int right = 1;
	bool force_jump = 0;
	static int p;
	static int enemynorm;
	static int enemyking;
	static int friendlynorm;
	static int friendlyking;

	cout << endl << "   Player " << player << "'s legal moves are : " << endl << endl;

	if (player == 1)
	{
		p = 1;
		enemynorm = norm2;
		enemyking = king2;
		friendlynorm = norm1;
		friendlyking = king1;
	}
	else if (player == 2)
	{
		p = -1;
		enemynorm = norm1;
		enemyking = king1;
		friendlynorm = norm2;
		friendlyking = king2;
	}

	force_jump = is_force_jump(checkers_board, p, left, right, enemynorm, enemyking, friendlynorm, friendlyking);

	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			//cout << "Looking at position " << i << "," << j << endl;
			clear_piece_q(q);

			(masterroot->child).clear(); //START HERE
			i_moves.clear();
			j_moves.clear();


			int current_pose_val = checkers_board[pos(i, j)];
			
			checkers_board[pos(i, j)] = nopiece;




			//q.push(root); // Enqueue root  
			//cout << "The front of the queue is " << q.front() << ". The back of the queue is " << q.back() << " and the size of the queue is " << q.size() << endl;


			// Case 1 : Open spaces for normal pieces
			if (current_pose_val == friendlynorm)
			{
				Piece* root = newPiece(i, j, current_pose_val);

				if (force_jump)
				{
					// Check if can jump opposing piece

					check_captures(checkers_board, i, j, p, left, enemynorm, enemyking, current_pose_val, root);
					i_captured.clear();
					j_captured.clear();
					check_captures(checkers_board, i, j, p, right, enemynorm, enemyking, current_pose_val, root);
					i_captured.clear();
					j_captured.clear();
				}
				else
				{
					// Open spaces for normal pieces
					check_open(checkers_board, i, j, p, left, current_pose_val, root);
					check_open(checkers_board, i, j, p, right, current_pose_val, root);
				}

				(masterroot->child).push_back(root);
				if ((root->child).size() > 0)
				{
					printPaths(masterroot);
					checkers_board[pos(i, j)] = current_pose_val;
					getPaths(checkers_board, masterroot, movesroot);
					checkers_board[pos(i, j)] = nopiece;
				}


			}

			if (current_pose_val == friendlyking)
			{
				Piece* root = newPiece(i, j, current_pose_val);

				if (force_jump)
				{
					// Check if can jump opposing piece

					check_captures(checkers_board, i, j, p, left, enemynorm, enemyking, current_pose_val, root);
					i_captured.clear();
					j_captured.clear();

					check_captures(checkers_board, i, j, p, right, enemynorm, enemyking, current_pose_val, root);
					i_captured.clear();
					j_captured.clear();

					check_captures(checkers_board, i, j, -p, left, enemynorm, enemyking, current_pose_val, root);
					i_captured.clear();
					j_captured.clear();

					check_captures(checkers_board, i, j, -p, right, enemynorm, enemyking, current_pose_val, root);
					i_captured.clear();
					j_captured.clear();


				}
				else
				{
					// Open spaces for normal pieces
					check_open(checkers_board, i, j, p, left, current_pose_val, root);
					check_open(checkers_board, i, j, p, right, current_pose_val, root);
					check_open(checkers_board, i, j, -p, left, current_pose_val, root);
					check_open(checkers_board, i, j, -p, right, current_pose_val, root);
				}
				//i_prev.clear(); j_prev.clear();

				//cout << "The root is at position " << root->current_i << "," << root->current_j << " and has children located at: " << endl;
				//cout << (root->child).size() << endl;
				//for (int size_t = 0; i < (root->child).size(); i++)
					//cout << root->child[i]->current_i << "," << root->child[i]->current_j << endl;

				(masterroot->child).push_back(root);

				if ((root->child).size() > 0)
				{
					printPaths(masterroot);
					checkers_board[pos(i, j)] = current_pose_val;
					getPaths(checkers_board, masterroot, movesroot);
					checkers_board[pos(i, j)] = nopiece;
				}
			}





			checkers_board[pos(i, j)] = current_pose_val;





		}
	}
	move_number = 0;
}


void locallegalmoves(int checkers_board[64], int player, Move* movesroot)
{

	static const int left = -1;
	static const int right = 1;
	bool force_jump = 0;
	static int p;
	static int enemynorm;
	static int enemyking;
	static int friendlynorm;
	static int friendlyking;

	//cout << endl << "Player " << player << "'s legal moves are : " << endl << endl;

	if (player == 1)
	{
		p = 1;
		enemynorm = norm2;
		enemyking = king2;
		friendlynorm = norm1;
		friendlyking = king1;
	}
	else if (player == 2)
	{
		p = -1;
		enemynorm = norm1;
		enemyking = king1;
		friendlynorm = norm2;
		friendlyking = king2;
	}

	force_jump = is_force_jump(checkers_board, p, left, right, enemynorm, enemyking, friendlynorm, friendlyking);

	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			//cout << "Looking at position " << i << "," << j << endl;
			clear_piece_q(q);

			(masterroot->child).clear(); //START HERE
			i_moves.clear();
			j_moves.clear();


			int current_pose_val = checkers_board[pos(i, j)];

			checkers_board[pos(i, j)] = nopiece;




			//q.push(root); // Enqueue root  
			//cout << "The front of the queue is " << q.front() << ". The back of the queue is " << q.back() << " and the size of the queue is " << q.size() << endl;


			// Case 1 : Open spaces for normal pieces
			if (current_pose_val == friendlynorm)
			{
				Piece* root = newPiece(i, j, current_pose_val);

				if (force_jump)
				{
					// Check if can jump opposing piece

					check_captures(checkers_board, i, j, p, left, enemynorm, enemyking, current_pose_val, root);
					i_captured.clear();
					j_captured.clear();
					check_captures(checkers_board, i, j, p, right, enemynorm, enemyking, current_pose_val, root);
					i_captured.clear();
					j_captured.clear();
				}
				else
				{
					// Open spaces for normal pieces
					check_open(checkers_board, i, j, p, left, current_pose_val, root);
					check_open(checkers_board, i, j, p, right, current_pose_val, root);
				}

				(masterroot->child).push_back(root);
				if ((root->child).size() > 0)
				{
					//printPaths(masterroot);
					checkers_board[pos(i, j)] = current_pose_val;
					getPaths(checkers_board, masterroot, movesroot);
					//LevelOrderTraversal(movesroot);
				}


			}

			if (current_pose_val == friendlyking)
			{
				Piece* root = newPiece(i, j, current_pose_val);

				if (force_jump)
				{
					// Check if can jump opposing piece

					check_captures(checkers_board, i, j, p, left, enemynorm, enemyking, current_pose_val, root);
					i_captured.clear();
					j_captured.clear();

					check_captures(checkers_board, i, j, p, right, enemynorm, enemyking, current_pose_val, root);
					i_captured.clear();
					j_captured.clear();

					check_captures(checkers_board, i, j, -p, left, enemynorm, enemyking, current_pose_val, root);
					i_captured.clear();
					j_captured.clear();

					check_captures(checkers_board, i, j, -p, right, enemynorm, enemyking, current_pose_val, root);
					i_captured.clear();
					j_captured.clear();


				}
				else
				{
					// Open spaces for normal pieces
					check_open(checkers_board, i, j, p, left, current_pose_val, root);
					check_open(checkers_board, i, j, p, right, current_pose_val, root);
					check_open(checkers_board, i, j, -p, left, current_pose_val, root);
					check_open(checkers_board, i, j, -p, right, current_pose_val, root);
				}
				//i_prev.clear(); j_prev.clear();

				//cout << "The root is at position " << root->current_i << "," << root->current_j << " and has children located at: " << endl;
				//cout << (root->child).size() << endl;
				//for (int size_t = 0; i < (root->child).size(); i++)
					//cout << root->child[i]->current_i << "," << root->child[i]->current_j << endl;

				(masterroot->child).push_back(root);

				if ((root->child).size() > 0)
				{
					//printPaths(masterroot);
					checkers_board[pos(i, j)] = current_pose_val;
					getPaths(checkers_board, masterroot, movesroot);
					//LevelOrderTraversal(movesroot);
				}
			}





			checkers_board[pos(i, j)] = current_pose_val;





		}
	}
	move_number = 0;
}





int* action(int checkers_board[64])
{
	size_t move_choice;
	cout << endl << "   Please enter your move choice : ";
	cin >> move_choice;
	cout << endl;

	while ((move_choice < 0 || move_choice > (movesroot->child).size()-1) || cin.fail())
	{
		cin.clear();
		cin.ignore(256, '\n');
		cout << "   Please enter a valid number for your move choice (an integer between 0 and " << (movesroot->child).size()-1 << "): ";
		cin >> move_choice;
	}

	//checkers_board = remove_pieces(checkers_board, (movesroot->child)[move_choice]);

	checkers_board = (movesroot->child)[move_choice]->checkers_board;
	


	//int initial_i = ((moves[2 * move_choice])[1]);
	//int initial_j = ((moves[2 * move_choice + 1])[1]);
	//int final_i = ((moves[2 * move_choice]).back());
	//int final_j = ((moves[2 * move_choice + 1]).back());

	//int location_i;
	//int location_j;
	//int future_i;
	//int future_j;
	//int sum = 0;
	//int temp = checkers_board[pos(initial_i, initial_j)];

	////cout << "The move choice has " << (moves[move_choice]).size() << " Points " << endl ;
	//for (int i = 1; i < (moves[2 * move_choice]).size() - 1; i++)
	//{
	//	location_i = (moves[2 * move_choice])[i];
	//	location_j = (moves[2 * move_choice + 1])[i];

	//	future_i = (moves[2 * move_choice])[i + 1];
	//	future_j = (moves[2 * move_choice + 1])[i + 1];

	//	sum += checkers_board[pos(avg(location_i, future_i), avg(location_j, future_j))];
	//	checkers_board[pos(avg(location_i, future_i), avg(location_j, future_j))] = nopiece;
	//	//cout << "Removed pieces at locations " << avg(location_i, future_i) << "," << avg(location_j, future_j) << endl;

	//}




	//checkers_board[pos(initial_i, initial_j)] = nopiece;
	////cout << "intial position: " << initial_i<< "," << initial_j << " has value: " << checkers_board[pos(initial_i, initial_j)]<<  endl;
	////cout << "final position: " << final_i << "," << final_j << " has value: " << checkers_board[pos(final_i, final_j)] << endl;
	//checkers_board[pos(final_i, final_j)] = temp;

	//cout << "Opposing player lost " << abs(sum) << " points" << endl;
	moves.clear();
	
	(movesroot->child).clear();
	return checkers_board;

}


int* AIaction(Move* move)
{
	static int checkers_board[64];

	memcpy(checkers_board, move->checkers_board, sizeof(checkers_board));
	(movesroot->child).clear();

	treemovesroot->child.clear();
	return checkers_board;

}







Move* testmovesroot = newMove(zero_vector, zero_vector, zero_vector, zero_vector, 0);
 

size_t is_game_done(int checkers_board[64], int player)
{

	bool player1wins = 1;
	bool player2wins = 1;
	/*for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			if (checkers_board[pos(i, j)] < 0)
				player1wins = 0;

			if (checkers_board[pos(i, j)] > 0)
				player2wins = 0;

			if (player1wins == 0 && player2wins == 0)
				break;
		}
		if (player1wins == 0 && player2wins == 0)
			break;
	}*/

	memcpy(testmovesroot->checkers_board, checkers_board, sizeof(testmovesroot->checkers_board));
	locallegalmoves(checkers_board, player, testmovesroot);

	if (testmovesroot->child.size() > 0)
	{
		player1wins = 0;
		player2wins = 0;
	}
	else if (testmovesroot->child.size() == 0)
	{
		if (player == 1)
		{
			player1wins = 0;
		}
		else if (player == 2)
		{
			player2wins = 0;
		}
	}

	testmovesroot->child.clear();

	if (player1wins == 1)
	{
		print_board_with_pieces(checkers_board);
		cout << endl << "             ";
		cb();
		cout << " CONGRATS PLAYER UNO YOU WONAROONO!!! ";
		bw();
		cout << endl << endl << endl << endl << endl;
		return 1;
	}
	else if (player2wins == 1)
	{
		print_board_with_pieces(checkers_board);
		cout << endl << "      ";
		yb();
		cout << " CONGRATS PLAYER DOS YOU MADE YOUR OPPONENT TOAST!!! ";
		bw();
		cout << endl << endl << endl << endl << endl;
		return 2;
	}
	else { return 0; }

}

void board()
{
	cout << endl;
	print_columns();
	print_line();
	int row = 0;
	for (int k = 0; k < 4; k++)
	{
		redrow(row);
		row += 1;
		print_line();
		blackrow(row);
		row += 1;
		print_line();

	}
}


//double heuristic(int checkers_board[64], Move* move)
//{
//	int temp_board[64];
//	memcpy(checkers_board, temp_board, sizeof(checkers_board));
//
//	int size = (move->i).size();
//	double sum = 0;
//
//	for (int i = 0; i < size; i++)
//	{
//		int initial_i = ((move->i)[0]);
//		int initial_j = ((move->j)[0]);
//		int final_i = ((move->i).back());
//		int final_j = ((move->i).back());
//
//		int location_i;
//		int location_j;
//		int future_i;
//		int future_j;
//		
//		int temp = temp_board[pos(initial_i, initial_j)];
//
//		//cout << "The move choice has " << (moves[move_choice]).size() << " Points " << endl ;
//		for (int i = 0; i < size; i++)
//		{
//			location_i = ((move->i)[i]);
//			location_j = ((move->j)[i]);
//
//			future_i = ((move->i)[i+1]); 
//			future_j = ((move->i)[i+1]); 
//
//			sum += temp_board[pos(avg(location_i, future_i), avg(location_j, future_j))];
//			temp_board[pos(avg(location_i, future_i), avg(location_j, future_j))] = nopiece;
//			//cout << "Removed pieces at locations " << avg(location_i, future_i) << "," << avg(location_j, future_j) << endl;
//
//		}
//
//
//
//
//		temp_board[pos(initial_i, initial_j)] = nopiece;
//		//cout << "intial position: " << initial_i<< "," << initial_j << " has value: " << checkers_board[pos(initial_i, initial_j)]<<  endl;
//		//cout << "final position: " << final_i << "," << final_j << " has value: " << checkers_board[pos(final_i, final_j)] << endl;
//		temp_board[pos(final_i, final_j)] = temp;
//
//		cout << "Opposing player will lose " << abs(sum) << " points" << endl;
//	}
//	return sum;
//}

void createMovesTree(int checkers_board[64], Move* node, int player, int depth)
{
	
	if (depth == 0)
	{
		return;
	}
	else
	{
		
		while (depth > 0)
		{
			depth--;
			locallegalmoves(checkers_board, player, node);
			player = player % 2 + 1;
			

			for (int ii = 0; ii < (node->child).size(); ii++)
			{
				createMovesTree((node->child)[ii]->checkers_board, node->child[ii], player, depth);
				
			}
			depth=-depth;
		}
		
	}
	
}


void print_root_sizes(Move* treemovesroot)
{

	if (treemovesroot->child.size() == 0)
	{
		cout << " no children here " << endl;
		return;
	}
	for (int childs = 0; childs < treemovesroot->child.size(); childs++)
	{
		if (treemovesroot->child[childs]->child.size() != 0)
		{
			cout << "size of root child " << childs << "'s child vector = " << treemovesroot->child[childs]->child.size() << endl;
			print_root_sizes(treemovesroot->child[childs]);
		}
	}
}


void printMovesTree(int checkers_board[64], int player, int depth)
{
	createMovesTree(checkers_board, treemovesroot, player, depth);
	cout << "size of root child vector = " << (treemovesroot->child).size() << endl;
	print_root_sizes(treemovesroot);
}

long currentTimeMillis()
{
	long ms;
	ms = chrono::duration_cast<chrono::milliseconds>(chrono::system_clock::now().time_since_epoch()).count();
	return ms;
}



bool searchCutoff = false;
int wincutoff = inf;


int distance(int checkers_board[64])
{
	vector<int> i1 = { 0 };
	vector<int> j1 = { 0 };
	vector<int> i2 = { 0 };
	vector<int> j2 = { 0 };


	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			if (checkers_board[pos(i, j)] > 0)
			{
				i1.push_back(i);
				j1.push_back(j);
			}
			else if (checkers_board[pos(i, j)] < 0)
			{
				i2.push_back(i);
				j2.push_back(j);
			}


		}
	}

	float distance = 0.0;

	for (int i = 0; i < i1.size(); i++)
	{
		for (int j = 0; j < i2.size(); j++)
		{
			distance += pow(pow(i1[i] - i2[j], 2) + pow(j1[i] - j2[j], 2), .5);
		}
	}

	//cout << "distance = " << (int)distance << endl;
	return (int)distance;
}

int edges(int checkers_board[64], int player)
{

	int player1edgepieces = 0;
	int player2edgepieces = 0;
	int player1homepieces = 0;
	int player2homepieces = 0;
	int player1kings = 0;
	int player2kings = 0;


	for (int i = 0; i < 8; i++)
	{
		if (i == 1 || i == 3 || i == 5)
		{
			if (checkers_board[pos(i, 0)] > 0)
			{
				player1edgepieces += checkers_board[pos(i, 0)];
			}
			else if (checkers_board[pos(i, 0)] < 0)
			{
				player2edgepieces += checkers_board[pos(i, 0)];
			}
		}
		else if (i == 2 || i == 4 || i == 6)
		{
			if (checkers_board[pos(i, 7)] > 0)
			{
				player1edgepieces += checkers_board[pos(i, 0)];
			}
			else if (checkers_board[pos(i, 7)] < 0)
			{
				player2edgepieces += checkers_board[pos(i, 0)];
			}
		}
		else if (i == 0)
		{
			for (int j = 0; j < 8; j++)
			{
				if (checkers_board[pos(i, j)] == norm2)
				{
					player2homepieces += checkers_board[pos(i, j)];
				}

				if (checkers_board[pos(i, j)] == king2)
				{
					player1kings += checkers_board[pos(i, j)];
				}
			}
		}
		else if (i == 7)
		{
			for (int j = 0; j < 8; j++)
			{
				if (checkers_board[pos(i, j)] == norm1)
				{
					player1homepieces += checkers_board[pos(i, j)];
				}
				if (checkers_board[pos(i, j)] == king1)
				{
					player2kings += checkers_board[pos(i, j)];
				}
			}
		}
	}



	if (player == 1)
	{
		return 5*abs(player1homepieces) + 9*abs(player1edgepieces) - 5*abs(player2homepieces) - 9*abs(player2edgepieces) - 5*abs(player2kings);
	}
	else if (player == 2)
	{
		return 5*abs(player2homepieces) + 9*abs(player2edgepieces) - 5*abs(player1homepieces) - 9*abs(player1edgepieces) - 5 * abs(player1kings);
	}

}

int heuristic(int checkers_board[64], Move* move, int player)
{
	int friendlyplayer = player;
	int enemyplayer = player % 2 + 1;
	//print_board_with_pieces(checkers_board);
	int friendlycount = count_pieces(checkers_board, friendlyplayer);
	int enemycount = count_pieces(checkers_board, enemyplayer);


	
	//cout << "Friendly player has " << friendlycount << " points" << endl;
	//cout << "Enemy player has " << enemycount << " points" << endl;
	//cout << endl;
	if (enemycount == 0)
	{
		//cout << "Player is gonna win!" << endl;
		return wincutoff;
	}
	else if (friendlycount == 0)
	{
		return -wincutoff;
	}
	else
	{
		if ((abs(friendlycount) + abs(enemycount)) < 16)
		{
			return distance(checkers_board);
		}
		else
		{
			//cout << "distance(checkers_board) = " << distance(checkers_board) << endl;
			// distance(checkers_board);
		return 10*abs(move->value) - 10*abs(enemycount) - distance(checkers_board)/10 + 15*abs(friendlycount) + edges(checkers_board, player);
			//cout << abs(move->value) - abs(enemycount) - distance(checkers_board) << endl;
		}
	}
	
}

//int player = 1; // CHANGE ME

int alphabeta(Move* node, int depth, int alpha, int beta, bool maximizingPlayer, long startTime, long timeLimit, int player)
{
	long currentTime = currentTimeMillis();
	long elapsedTime = (currentTime - startTime);

	if (currentTime >= startTime + timeLimit) {
		searchCutoff = true;
		return INT_MIN;
	}

	


	//cout << "Looking at depth = " << depth << endl;
	//if (node->child.size() > 0)
	//{
	//	for (int ii = 0; ii < node->child.size(); ii++)
	//	{
	//		int blimp = alphabeta(node->child[ii], depth - 1, alpha, beta, !maximizingPlayer, startTime, timeLimit);
	//		node->score = blimp;
	//	}
	//	
	//}

	if (node->child.size() == 0)
	{
		locallegalmoves(node->checkers_board, node->player, node);
	}

	int score = heuristic(node->checkers_board, node, player);

	if (node == treemovesroot)
	{
		score = 0;
	}

	//cout << "treemovesroot->child.size() = " << treemovesroot->child.size() << endl;


	if ( (depth == 0) || (node->child.size() == 0) || (score >= wincutoff)) {
		//cout << "Winning move value returned" << endl;
		//print_board_with_pieces(node->checkers_board);
		//node->child.clear();
		node->score = score;
		return score;
	}


	

	

	
	

	//if (depth <= 0 || node->child.size() == 0)
	//{
	//	//cout << "You get " << node->value << " points from this move" << endl;
	//	node->child.clear();
	//	//cout << "Hueristic Value - " << -heuristic(node->checkers_board, node, node->player) << " for a move from " << node->i[1] << "," << node->j[1] << " to " << node->i.back() << "," << node->j.back() << endl;
	//	//cout << "calculating heurisitc" << endl;
	//	return heuristic(node->checkers_board, node, node->player);
	//}
	//cout << maximizingPlayer << endl;
	
	if (maximizingPlayer)
	{
		int value = -inf;
		//cout << "Node has " << node->child.size() << " children" << endl;
		for (int ii = 0; ii < node->child.size(); ii++)
		{
			//cout << "Maximizing" << endl;
			//cout << "Looking at child " << ii << endl;
			//print_board_with_pieces(node->child[ii]->checkers_board);
			//cout << "depth-1 = " << depth - 1 << endl;
			int blimp = alphabeta(node->child[ii], depth - 1, alpha, beta, false, startTime, timeLimit, player);
			value = max(value, blimp);
			node->score = value;
			//cout << "value = " << value << endl;
			//cout << "alpha before = " << alpha << endl;
			alpha = max(alpha, value);

			//cout << "alpha after = " << alpha << endl;
			if (alpha >= beta)
			{
				//cout << "BREAKING " << alpha << " >= " << beta << endl;
				break;
			}
			
		}
		return value;
	}
	else
	{
		//cout << "Node has " << node->child.size() << " children" << endl;
		int value = inf;
		for (int ii = 0; ii < (node->child).size(); ii++)
		{
			//cout << "Anti-maximizing" << endl;
			//cout << "Looking at child " << ii << endl;
			//print_board_with_pieces(node->child[ii]->checkers_board);
			int blimp = alphabeta(node->child[ii], depth - 1, alpha, beta, true, startTime, timeLimit, player);
			value = min(value,blimp);
			node->score = value;
			//cout << "value = " << value << endl;
			//cout << "beta before = " << beta << endl;
			beta = min(beta, value);
			
			//cout << "beta after = " << beta << endl;
			if (beta <= alpha)
			{
				//cout << "BREAKING " << beta << " <= " << alpha << endl;
				break;
			}
		}	
		return value;
	}
}				


//(*Initial call*)
//alphabeta(origin, depth, -inf, +inf, TRUE)


//void iterative_deepening()
//{
//	for (int distance = 1; distance < MAX_DISTANCE && !outOfTime(); distance++) {
//		bestmove = alphaBetaAtRoot(position, distance);
//	}
//	play(bestmove);
//}

void copy_move(Move* temproot, Move* move_to_copy)
{
	memcpy(temproot->checkers_board, move_to_copy->checkers_board, sizeof(temproot->checkers_board));
	temproot->player = move_to_copy->player;
	temproot->child = move_to_copy->child;
	temproot->score = move_to_copy->score;

}




vector<int> maxDepthVector = { 0 };

int iterativeDeepeningSearch(Move* root, int cutoffDepth, long searchTimeLimit){//int timeLimit) {
	int startTime = currentTimeMillis();
	long endTime = startTime + searchTimeLimit;


	//cout << "Starting at " << startTime << " second." << endl;
	//cout << "Ending at " << endTime << " second." << endl;
	//cout << "The time limit is " << searchTimeLimit << " seconds" << endl;
	vector<Move*> previousMoveScores;

	int depth = 1;
	

	int searchResult = 0;
	int checkers_board[64];

	memcpy(checkers_board, root->checkers_board, sizeof(checkers_board));

	//Move* temproot = newMove(zero_vector, zero_vector, zero_vector, zero_vector, 0);
	//copy_move(temproot, treemovesroot);

	int prevscore = INT_MIN;


	while (depth < cutoffDepth) {
		int score = 0;
		//cout << "Searching depth " << depth << endl; 
		//treemovesroot->child.clear();

		searchCutoff = false;
		long currentTime = currentTimeMillis();

		if (currentTime >= endTime) {
			cout << "   Time Limit reached. Searched to depth " << depth-1 << endl;
			break;
		}
		//cout << "depth = " << depth << " and cutoff depth = " << cutoffDepth << endl;
		//searchResult = alphabeta(treemovesroot, depth, -inf, inf, TRUE);
		if ( (currentTime - startTime) > searchTimeLimit / 2)
		{
			break;
		}

		//for (int ii = 0; ii < treemovesroot->child.size(); ii++)
		//{
		//	cout << "Move " << ii << " score = " << treemovesroot->child[ii]->score << " at depth " << depth << endl;
		//}
		
		searchResult = alphabeta(root, depth, -inf, inf, true, currentTime, endTime - currentTime, treemovesroot->player);
		
		if (searchCutoff)
		{

			cout << "The search cut off while searching to depth " << depth << ". Returning the best move from depth = " << depth - 1 << endl;

			//for (int ii = 0; ii < treemovesroot->child.size(); ii++)
			//{
			//	cout << "Move " << ii << " score = " << treemovesroot->child[ii]->score << endl;
			//}

			for (int ii = 0; ii < treemovesroot->child.size(); ii++)
			{
				Move* temproot = newMove(zero_vector, zero_vector, zero_vector, zero_vector, 0);
				copy_move(temproot, previousMoveScores[ii]);
				copy_move(treemovesroot->child[ii], temproot);
			}
			
			//for (int ii = 0; ii < treemovesroot->child.size(); ii++)
			//{
			//	cout << "Move " << ii << " score = " << treemovesroot->child[ii]->score << endl;
			//}
			break;
		}
		
		//cout << "Score = " << searchResult << " at depth " << depth << endl;
		//
		// If the search finds a winning move, stop searching
		//
		if (searchResult >= wincutoff)
		{
			maxDepthVector.push_back(depth);
			score = searchResult;
			//cout << "Winning move found" << endl;
			//cout << "Score from depth " << depth - 1 << " recorded as " << prevscore << endl;
			prevscore = score;
			//cout << "Score from depth " << depth << " recorded as " << score << endl;
			return score;
		}
		else if (!searchCutoff)
		{
			score = searchResult;
			//cout << "Score from depth " << depth-1 << " recorded as " << prevscore << endl;
			prevscore = score;
			//cout << "Score from depth " << depth << " recorded as " << score << endl;


			previousMoveScores.clear();
			for (int ii = 0; ii < treemovesroot->child.size(); ii++)
			{
				Move* temproot = newMove(zero_vector, zero_vector, zero_vector, zero_vector, 0);
				
				copy_move(temproot, treemovesroot->child[ii]);
				
				previousMoveScores.push_back(temproot);
			}
			

		}
		

		maxDepthVector.push_back(depth);


		depth++;
		

	}



	//copy_move(treemovesroot, temproot);

	//cout << "max value = " << searchResult << endl;
	//cout << "prevscore = " << prevscore << endl;
	return prevscore;

}




Move* chooseMove(int cutoffDepth)
{
	long startTime = currentTimeMillis();
	Move* bestmove = NULL;
	int maxScore = INT_MIN;
	long timespan;
	int checkers_board[64];
	int player;
	int maxDepth = 0;
	//cout << "The time limit is " << time_limit << endl;
	memcpy( checkers_board, treemovesroot->checkers_board, sizeof(checkers_board));
	//print_board_with_pieces(checkers_board);
	player = treemovesroot->player;
	//cout << "Player " << player << "'s turn" << endl;
	
	
	legalmoves(checkers_board, player);
	
	
	
	
	// Print out legal moves
	// Store legal moves in the root
	// if the legal move is just 1, take it
	// for each child in the legal moves, 

	// implement a time limit
	// perform an iterative deppening search 

	//if (score >= wincutoff)
	//{
	//	//cout << "   Found a winning scenario" << endl;
	//	timespan = (currentTimeMillis() - startTime) / 1000;
	//	cout << "   Search lasted " << timespan << " seconds" << endl;
	//	auto it = *max_element(std::begin(maxDepthVector), std::end(maxDepthVector));
	//	//cout << "it = " << it << endl;
	//	maxDepth = it;
	//	cout << "   Max Depth searched to = " << maxDepth - 1 << endl;
	//	maxDepthVector.clear();
	//	cout << "Choosing move which goes from " << move->i[1] << "," << move->j[1] << " to " << move->i.back() << "," << move->j.back() << " and is worth " << move->score << "points" << endl;
	//	return move;
	//}

	//if (score > maxScore) {
	//	maxScore = score;
	//	bestmove = move;
	//}

	
	
	//cout << "treemovesroot.size() before local legale moves = " << treemovesroot->child.size() << endl;
	locallegalmoves(checkers_board, player, treemovesroot);
	//cout << "treemovesroot.size() after local legal moves = " << treemovesroot->child.size() << endl;

	int treemovesrootchildsize = treemovesroot->child.size();

	if (treemovesrootchildsize == 1)
	{
		return treemovesroot->child[0];
	}


	cout << endl << "   The computer is searching for a move to make..." << endl << endl;

	//for (int ii = 0; ii < treemovesrootchildsize; ii++)
	//{
		//cout << "looking at move " << ii << endl;
	//Move* move = treemovesroot->child[ii];

	//long searchTimeLimit = ((time_limit - 1000) / (treemovesroot->child.size()));

		//cout << "time_limit - 1 = " << time_limit - 1000 << endl;
		//cout << "treemovesroot->child.size() = " << treemovesroot->child.size() << endl;
		//cout << "The time limit is " << searchTimeLimit << " seconds" << endl;


	int score = iterativeDeepeningSearch(treemovesroot, cutoffDepth, time_limit);
	//cout << "move " << ii << " worth " << score << " points" << endl;

		//cout << "move " << ii << " goes from " << move->i[1] << "," << move->j[1] << " to " << move->i.back() << "," << move->j.back() << endl;

	vector<Move*> bestmovevector;


	//cout << "   Best Move worth " << score << " points" << endl;

	for (int ii = 0; ii < treemovesrootchildsize; ii++)
	{
		Move* move = treemovesroot->child[ii];
		//cout << "   Move " << ii << " worth " << move->score << " points" << endl;
		//if (move->score >= wincutoff)
		//{
		//	cout << "Found a winning move" << endl;
		//	bestmove = move;
		//}
		if (move->score == score)
		{
			bestmovevector.push_back(move);
		}

	}

	//if (score >= wincutoff)
	//{
	//	//cout << "   Found a winning scenario" << endl;
	//	timespan = (currentTimeMllis()-startTime) / 1000;
	//	cout << "   Search lasted " << timespan << " seconds" << endl;
	//	auto it = *max_element(std::begin(maxDepthVector), std::end(maxDepthVector));
	//	//cout << "it = " << it << endl;
	//	maxDepth = it;
	//	cout << "   Max Depth searched to = " << maxDepth-1 << endl;
	//	maxDepthVector.clear();
	//	cout << "Choosing move which goes from " << move->i[1] << "," << move->j[1] << " to " << move->i.back() << "," << move->j.back() << " and is worth " << move->score << "points" << endl;
	//	return move;
	//}

	//if (score > maxScore) {
	//	maxScore = score;
	//	bestmove = move;
	//}

		//cout << "treemovesroot.size() at end of loop = " << treemovesroot->child.size() << endl;


	//cout << "maxScore = " << maxScore << endl;
	//cout << "bestmove -> score = " << bestmove->score << endl;
	//cout << "bestmove goes from " << bestmove->i[1] << "," << bestmove->j[1] << " to " << bestmove->i.back() << "," << bestmove->j.back() << endl;


	//for (int ii = 0; ii < treemovesroot->child.size(); ii++)
	//{
	//	Move* move = treemovesroot->child[ii];
	//	
	//	if (move->score == maxScore)
	//	{
	//		
	//		bestmovevector.push_back(move);
	//	}
	//}
	// Get bestmoves vector and randomlly choose a move
	//cout << "bestmovevector.size() = " << bestmovevector.size() << endl;

	if (bestmovevector.size() > 1)
	{
		int randomIndex = rand() % bestmovevector.size();
		bestmove = bestmovevector[randomIndex];
		//cout << "Randomly choosing move " << randomIndex << ", which goes from " << bestmove->i[1] << "," << bestmove->j[1] << " to " << bestmove->i.back() << "," << bestmove->j.back() <<  endl;
	}
	else
	{
		bestmove = bestmovevector[0];
	}
	//cout << "Choosing move which goes from " << bestmove->i[1] << "," << bestmove->j[1] << " to " << bestmove->i.back() << "," << bestmove->j.back() << " and is worth " << bestmove->score << " points" << endl;
	timespan = (currentTimeMillis() - startTime) / 1000;
	cout << "   Search lasted " << timespan << " seconds" << endl;
	auto it = *max_element(std::begin(maxDepthVector), std::end(maxDepthVector));
	maxDepth = it;
	cout << "   Max Depth searched to = " << maxDepth << endl;

	//printMovesTree(treemovesroot->checkers_board, treemovesroot->player, maxDepth);

	maxDepthVector.clear();
	return bestmove;

}


