// AI Checkers.cpp : This file contains the 'main' function. Program execution begins and ends there.
// cntrl K + cntrl C to comment
// cntrl K + cntrl U to comment

#include <iostream>
#include <fstream>
#include <string>
#include "func.h"
using namespace std;

//void AIPlayer();
//void humanPlayer();

void drawstate(int drawcondition)
{
    if (40 - drawcondition == 20 || 40 - drawcondition == 20+1 || 40 - drawcondition == 30 || 40 - drawcondition == 30+1 || 40 - drawcondition < 11)
    {
        if (40 - drawcondition == 1)
        {
            cout << endl;
            cout << "   ";
            ry();
            cout << " WARNING: A piece must be captured within " << 40 - drawcondition << " move or a draw will be declared "; 
            bw(); 
            cout << endl;
        }
        else
        {
            cout << endl;
            cout << "   ";
            ry();
            cout << " WARNING: A piece must be captured within " << 40 - drawcondition << " moves or a draw will be declared ";
            bw();
            cout << endl;
            
        }
    }
}

int main()
{
    bw();
    const int board_width = 8;
    int player = 0;
    const int nopiece = 0;
    const int norm1 = 3;
    const int king1 = 5;
    const int norm2 = -3;
    const int king2 = -5;
    bool loadfile = 0;
    bool player1gender = 0; // gender of 0 is human player, gender of 1 is computer player
    bool player2gender = 0; // gender of 0 is human player, gender of 1 is computer player
	vector<int> zero_vector = { 0 };
    //string path = "C:/Users/enead/Desktop/Enea Dushaj/School/Artificial Intelligence/Checkers Game/Sample Boards/Sample Checkers board #10.txt";
    int *checkers_board;

    loadfile = load_file();

    if (loadfile == 1)
    {
        string path = get_file_path();
        checkers_board = load_file_contents(path);
        player = load_file_contents_player(path);
    }
    else
    {
        checkers_board = create_starting_board();
        create_time_limit();
        player = move_first();
    }

    int cutoffDepth = 15;
    store_board_in_tree_moves_root(checkers_board);

    player1gender = determine_player1();
    player2gender = determine_player2();


    
    store_player_in_tree_moves_root(player);


    int drawcondition = 0;
    int tempboard[64];
    
	while (is_game_done(checkers_board, player) == 0 && drawcondition<40)
	{

        int player1count = count_pieces(checkers_board, 1);
        int player2count = count_pieces(checkers_board, 2);

        if (player == 1)
        {
            if (player1gender == 0)
            {
                store_player_in_tree_moves_root(player);
                print_board_with_pieces(checkers_board);
                drawstate(drawcondition);
                legalmoves(checkers_board, player);
                checkers_board = action(checkers_board);
                
            }
            else if (player1gender == 1)
            {
                print_board_with_pieces(checkers_board);
                drawstate(drawcondition);
                store_player_in_tree_moves_root(player);
                //printMovesTree(checkers_board, 1, cutoffDepth);
                //iterativeDeepeningSearch(checkers_board,  cutoffDepth);

                store_board_in_tree_moves_root(checkers_board);
                

                checkers_board = AIaction(chooseMove(cutoffDepth));
                
            }
            player = player % 2 + 1;
        }
        else if (player == 2)
        {
            if (player2gender == 0)
            {
                store_player_in_tree_moves_root(player);
                print_board_with_pieces(checkers_board);
                drawstate(drawcondition);
                legalmoves(checkers_board, player);
                checkers_board = action(checkers_board);
                
            }
            else if (player2gender == 1)
            {
                print_board_with_pieces(checkers_board);
                drawstate(drawcondition);
                store_player_in_tree_moves_root(player);
                //printMovesTree(checkers_board, 1, cutoffDepth);
                //iterativeDeepeningSearch(checkers_board,  cutoffDepth);

                store_board_in_tree_moves_root(checkers_board);
                

                checkers_board = AIaction(chooseMove(cutoffDepth));
          
            }
            player = player % 2 + 1;
        }

        if (player1count == count_pieces(checkers_board, 1) && player2count == count_pieces(checkers_board, 2))
        {
            drawcondition++;
        }
        else
        {
            drawcondition = 0;
        }
        //cout << "   There are " << 40 - drawcondition << " moves until a draw is declared" << endl;
	}

    if (drawcondition == 40)
    {
        print_board_with_pieces(checkers_board);
        cout << endl << endl << "             "; 
        ry();
        cout << "MATCH HAS ENDED IN A DRAW :( ";
        bw();
        cout << endl << endl;

    }
    
}

//void AIPlayer()
//{
//    store_player_in_tree_moves_root(player);
//    //printMovesTree(checkers_board, 1, cutoffDepth);
//    //iterativeDeepeningSearch(checkers_board,  cutoffDepth);
//
//    store_board_in_tree_moves_root(checkers_board);
//    print_board_with_pieces(checkers_board);
//
//    checkers_board = AIaction(chooseMove(cutoffDepth));
//    player = player % 2 + 1;
//
//}
//
//void humanPlayer()
//{
//    store_player_in_tree_moves_root(player);
//    print_board_with_pieces(checkers_board);
//    legalmoves(checkers_board, player);
//    checkers_board = action(checkers_board);
//    player = player % 2 + 1;
//}

